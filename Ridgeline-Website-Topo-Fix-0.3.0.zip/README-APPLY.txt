Ridgeline website Topo clarity fix

Replace the four public/ files in the existing v115 website source and build/deploy normally. Preserve every other file, server handler and archive asset.

Changes: native-resolution flat Topo rendering; no aerial motion/phone detail reduction for printed maps; nearest raster sampling; no photo crossfade; zoom capped at the existing raster source limit. Photo rendering settings return when switching back. Cache-busted viewer/app/performance module imports are included.

Website source checks passed. This ZIP has not been deployed to the original live Site by this cloud session. The original Site editing/deployment session must apply it.
